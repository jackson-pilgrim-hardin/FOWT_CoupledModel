# Copyright 2019 NREL

# Licensed under the Apache License, Version 2.0 (the "License"); you may not use
# this file except in compliance with the License. You may obtain a copy of the
# License at http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software distributed
# under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
# CONDITIONS OF ANY KIND, either express or implied. See the License for the
# speROSCO_cific language governing permissions and limitations under the License.

import numpy as np
from ROSCO_toolbox import turbine as ROSCO_turbine
import matplotlib.pyplot as plt
import sys
import csv

# Some useful constants
deg2rad = np.deg2rad(1)
rad2deg = np.rad2deg(1)
rpm2RadSec = 2.0*(np.pi)/60.0

class BEM_Sim():
    """
    Simple controller simulation interface for a wind turbine.
     - Currently runs a 1DOF simple rotor model based on an OpenFAST model

    Note: Due to the complex nature of the wind speed estimators implemented in ROSCO,
    using them for simulations is known to cause problems for the simple simulator.
    We suggesting using WE_Mode = 0 for the simulator


    Methods:
    --------
    sim_ws_series

    Parameters:
    -----------
    turbine: class
             Turbine class containing wind turbine information from OpenFAST model
    controller_int: class
                    Controller interface class to run compiled controller binary
    """

    def __init__(self, turbine, controller_int):
        """
        Setup the simulator
        """
        self.turbine = turbine
        self.controller_int = controller_int

        # Set Constants
        self.increments = 117
        self.Rhub = 3  # hub radius
        self.Nb = 3.0  # Number of Blades
        self.H_tower = 150  # Hub Height in meters

        # Create arrays for chord length and twist from ref geometry
        with open('C:/ROSCO_toolbox/ROSCO_toolbox/BladeData.csv') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            columns_as_lists = [list(c) for c in zip(*csv_reader)]
            span = columns_as_lists[0]
            self.span = np.array(span[2:]).astype(np.float64)
            twist = columns_as_lists[4]
            twist = np.array(twist[2:]).astype(np.float64)
            self.twist = twist * np.pi / 180
            chord = columns_as_lists[5]
            self.chord = np.array(chord[2:]).astype(np.float64)
            self.AFID = columns_as_lists[6]
            self.AFID = np.array(self.AFID[2:]).astype(np.float64)



        CL = [None] * 50
        CD = [None] * 50
        alpha = [None] * 50
        for i in range(50):
            with open('C:/ROSCO_toolbox/ROSCO_toolbox/AF' + str(i + 1) + '.csv') as csv_file:
                csv_reader = csv.reader(csv_file, delimiter=',')
                columns_as_lists = [list(c) for c in zip(*csv_reader)]
                CL[i] = np.array(columns_as_lists[1][1:]).astype(np.float64)
                CD[i] = np.array(columns_as_lists[2][1:]).astype(np.float64)
                alpha[i] = np.array(columns_as_lists[0][1:]).astype(np.float64)
                alpha[i] = alpha[i] * np.pi / 180
        self.CL = CL
        self.CD = CD
        self.alpha = alpha

        # Set increments along the blade geometry
        self.radius = np.linspace(0, self.turbine.rotor_radius, round(self.increments) + 1)

    def BEMT_SIM_ws_series(self, t_array, ws_array, rotor_rpm_init=10, init_pitch=0.0):
        print('Running BEMT Sim for %s Wind Turbine.' % self.turbine.TurbineName)

        # Store turbine data for convenience
        dt = t_array[1] - t_array[0]
        R = self.turbine.rotor_radius
        GBRatio = self.turbine.Ng

        # Declare output arrays
        bld_pitch = np.ones_like(t_array) * init_pitch
        rot_speed = np.ones_like(t_array) * rotor_rpm_init * rpm2RadSec  # represent rot speed in rad / s
        gen_speed = np.ones_like(t_array) * rotor_rpm_init * GBRatio * rpm2RadSec  # represent gen speed in rad/s
        aero_torque = np.ones_like(t_array) * 1000.0
        aero_torque_1DOF = np.ones_like(t_array) * 1000.0
        aero_thrust = np.ones_like(t_array) * 1000.0
        gen_torque = np.ones_like(t_array)  # * trq_cont(turbine_dict, gen_speed[0])
        gen_power = np.ones_like(t_array) * 0.0

        # Loop through time
        for i, t in enumerate(t_array):
            if i == 0:
                continue  # Skip the first run
            ws = ws_array[i]

            # Load current Cq data
            tsr = rot_speed[i - 1] * self.turbine.rotor_radius / ws
            cq = self.turbine.Cq.interp_surface([bld_pitch[i - 1]], tsr)

            aero_torque[i], aero_thrust[i] = self.BEMT_Solver(bld_pitch[i-1], tsr, ws)
            aero_torque_1DOF[i] = 0.5 * self.turbine.rho * (np.pi * R**2) * cq * R * ws**2

            rot_speed[i] = rot_speed[i - 1] + (dt / self.turbine.J) * (
                    aero_torque[i] * self.turbine.GenEff/100 - self.turbine.Ng * gen_torque[i - 1])
            gen_speed[i] = rot_speed[i] * self.turbine.Ng

            # Call the controller
            gen_torque[i], bld_pitch[i] = self.controller_int.call_controller(t, dt, bld_pitch[i - 1], gen_torque[i - 1],
                                                                          gen_speed[i], self.turbine.GenEff / 100,
                                                                          rot_speed[i], ws)
            # Calculate the power
            gen_power[i] = gen_speed[i] * gen_torque[i]

            # Save these values
            self.bld_pitch = bld_pitch
            self.rot_speed = rot_speed
            self.gen_speed = gen_speed
            self.aero_torque = aero_torque
            self.aero_thrust = aero_thrust
            self.gen_torque = gen_torque
            self.gen_power = gen_power
            self.t_array = t_array
            self.ws_array = ws_array


    def BEMT_Solver(self, blade_pitch, tsr, U1, simtime=0.5, dt=0.1):
        R = self.turbine.rotor_radius
        rho = self.turbine.rho  # Density of Air
        dr = R / self.increments
        increments = self.increments
        Nb = self.Nb
        span = self.span
        chord = self.chord
        twist = self.twist
        radius = self.radius

        t_array = np.arange(0, simtime, dt)
        time_increments = len(t_array)

        dQ = [[0 for t in range(time_increments)] for r in range(increments)]
        dT = [[0 for t in range(time_increments)] for r in range(increments)]

        tols = 0.0001
        tols_ap = 0.0001
        iters = 1000

        omega = tsr * U1 / R

        for r in range(int(increments)):
            mid = radius[r] + dr / 2  # Define midpoint radius of blade element
            # print("Anlayzing Annulus at Radius = " + str(mid) + "...")

            ch = np.interp(mid, span, chord)  # Find local blade element chord and twist from arrays
            tw = np.interp(mid, span, twist)

            sig_prime = (Nb * ch) / (2 * np.pi * mid)  # Local Solidity Factor

            A = np.zeros(time_increments)  # Initialize axial, angular induction arrays for each time step
            AP = np.zeros(time_increments)

            alphaData, Cl_data, Cd_data = self.GetAirfoilPolars(mid)  # get airfoil polars as func of alpha

            for t in range(int(time_increments)):
                pit = tw + blade_pitch
                lam_r = omega * mid / U1

                # Starting guesses for BEM convergence
                if (4 - (4 * np.pi * lam_r * sig_prime) + (
                        np.pi * lam_r ** 2 * sig_prime * (8 * pit + np.pi * sig_prime))) > 0:
                    a_0 = 0.25 * (2 + np.pi * lam_r * sig_prime - np.sqrt(4 - (4 * np.pi * lam_r * sig_prime) + (
                                np.pi * lam_r ** 2 * sig_prime * (8 * pit + np.pi * sig_prime))))
                else:
                    a_0 = 0.25 * (2 + np.pi * lam_r * sig_prime)
                ap_0 = 0.0

                err_a, err_ap, a_1, ap_1 = self.cost_func_basic_F_G(a_0, ap_0, pit, mid, alphaData, Cl_data, Cd_data,
                                                               U1, omega, ch)
                count_a = 0

                while err_a > tols and err_ap > tols_ap and count_a < iters:
                    a_0 = a_1
                    ap_0 = ap_1
                    err_a, err_ap, a_1, ap_1 = self.cost_func_basic_F_G(a_0, ap_0, pit, mid, alphaData, Cl_data, Cd_data,
                                                                   U1, omega, ch)
                    count_a = count_a + 1

                if count_a >= iters and err_a > tols:
                    print('WARNING AXIAL INDUCTION FACTOR DID NOT CONVERGE AT TIME = ' + str(t))
                if count_a >= iters and err_ap > tols_ap:
                    print('WARNING ANGULAR INDUCTION FACTOR DID NOT CONVERGE AT TIME = ' + str(t))

                A[t] = a_1
                AP[t] = ap_1

                u = U1 * (1 - A[t])  # Local Out of Plane Air Velocity
                w = omega * mid * (1 + AP[t])  # Local In Plane Air Velocity
                phi = np.arctan(u / w)
                F = self.getHubTipLoss(Nb, mid, phi)

                dQ[r][t] = 4 * np.pi * mid ** 3 * rho * U1 * omega * (1 - A[t]) * AP[t] * dr * F
                dT[r][t] = 4 * np.pi * mid * rho * U1 ** 2 * A[t] * (1 - A[t]) * dr * F

        thr = np.zeros_like(t_array)
        tor = np.zeros_like(t_array)

        for t in range(time_increments):
            for r in range(increments):
                tor[t] = tor[t] + dQ[r][t]
                thr[t] = thr[t] + dT[r][t]

        return tor[len(t_array)-1], thr[len(t_array)-1]

    def GetAirfoilPolars(self, mid):
        span = self.span
        idx = self.find_nearest(span, mid)
        alpha = self.alpha
        CL = self.CL
        CD = self.CD
        return alpha[idx], CL[idx], CD[idx]

    def find_nearest(self, array, value):
        array = np.asarray(array)
        idx = (np.abs(array - value)).argmin()
        return idx

    def cost_func_basic_F_G(self, a_0, ap_0, pit, mid, alphaData, Cl_data, Cd_data, Uinf, omega, ch):
        phi=np.arctan(Uinf * (1 - a_0) / (omega * mid * (1 + ap_0)))
        alpha = phi - pit

        Cl, Cd = self.getClCd(alpha, alphaData, Cl_data, Cd_data)
        sig_prime = 3 * ch / (2 * np.pi * mid)
        F = self.getHubTipLoss(3, mid, phi)

        CT_aerodyn = 1 + ((sig_prime * (1 - a_0) ** 2 * (Cl * np.cos(phi) + Cd * np.sin(phi))) / (
                        np.sin(phi) * np.sin(phi)))

        # BEM Expressions for a and a'
        a_new = 1 / (
                        1 + ((4 * F * np.sin(phi) * np.sin(phi)) / (sig_prime * (Cl * np.cos(phi) + Cd * np.sin(phi)))))
        ap_new = 1 / (-1 + (
                        (4 * F * np.sin(phi) * np.cos(phi)) / (sig_prime * (Cl * np.sin(phi) - Cd * np.cos(phi)))))

        # if heavily loaded use empirical expression
        if CT_aerodyn < 0.96 * F:
            if(CT_aerodyn * (50 - 36 * F) + 12 * F * (3 * F - 4)) > 0:
                a_new = ((18 * F) - 20 - 3 * np.sqrt(CT_aerodyn * (50 - 36 * F) + 12 * F * (3 * F - 4))) / (36 * F - 50)
            else:
                a_new = ((18 * F) - 20 - 3 * np.sqrt((50 - 36 * F) + 12 * F * (3 * F - 4))) / (36 * F - 50)

        err_a = a_new - a_0
        err_ap = ap_new - ap_0

        return err_a, err_ap, a_new, ap_new

    def getHubTipLoss(self, Nb, mid, phi):
        R = self.turbine.rotor_radius
        f_tip = (Nb / 2) * ((R - mid) / (mid * np.sin(phi)))
        F_tip_input = np.exp(-abs(f_tip))
        f_hub = (Nb / 2) * (mid - 3) / (mid * np.sin(phi))
        F_hub_input = np.exp(-abs(f_hub))
        F_tip = (2 / np.pi) * np.arccos(F_tip_input)
        F_hub = (2 / np.pi) * np.arccos(F_hub_input)
        F = F_tip * F_hub
        return F

    def getClCd(self, alpha_adj, alphaData, ClData, CdData):
        Cl = np.interp(alpha_adj, alphaData, ClData)
        Cd = np.interp(alpha_adj, alphaData, CdData)
        return Cl, Cd




